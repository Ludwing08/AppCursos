export interface Curso{
    id ?: number,
    imagen : string,
    titulo: string,
    subtitulo: string,
    categoria : string,
    favoritos: number
}